﻿using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Felvételi
{
    public partial class MainWindow : Window
    {
        ObservableCollection<IFelvetelizo> Frissit = new ObservableCollection<IFelvetelizo>();
        public MainWindow()
        {
            InitializeComponent();
            dgSzoveg.ItemsSource = Frissit;
        }
        private void btnImport_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Fájlkiválasztás";
            ofd.Filter = "Adattábla(*.csv)|*.csv";
            if ((bool)ofd.ShowDialog())
            {
                try
                {
                    StreamReader sr = new StreamReader(ofd.FileName);
                    sr.ReadLine();
                    while (!sr.EndOfStream)
                    {
                        string[] sor = sr.ReadLine().Trim().Split(';');
                        if (sor[5] == "NULL")
                        {
                            sor[5] = "0";
                        }
                        else if (sor[6] == "NULL")
                        {
                            sor[6] = "0";
                        }
                        Diak adat = new Diak(sor[0], sor[1], sor[2], DateTime.Parse(sor[3]), sor[4], int.Parse(sor[5]), int.Parse(sor[6]));
                        Frissit.Add(adat);
                    }
                    sr.Close();
                   
                }
                catch (Exception)
                {
                    MessageBox.Show("Ez a fájl nem betölthető");
                }
            }
        }

        private void btnTorles_Click(object sender, RoutedEventArgs e)
        {
            if (dgSzoveg.SelectedItems.Count > 0)
            {
                List<object> selectedItems = new List<object>();

                foreach (var selectedItem in dgSzoveg.SelectedItems)
                {
                    selectedItems.Add(selectedItem);
                }

                foreach (var selectedItem in selectedItems)
                {
                    Frissit.Remove(selectedItem);
                }
            }
            else
            {
                MessageBox.Show("Jelölj ki egy diákot!");
            }
        }

        private void btnUjDiak_Click(object sender, RoutedEventArgs e)
        {
            userAdd u = new userAdd();
            u.ShowDialog();
            
            try
            {
                
                Frissit.Add(new Diak(u.txtOmAzon.Text, u.txtNev.Text, u.txtEmail.Text, Convert.ToDateTime(u.txtSzulDatum.Text), u.txtertesites.Text, Convert.ToInt16(u.txtMatekJegy.Text), Convert.ToInt16(u.txtMagyar.Text)));
                u.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Valamelyik adat hibásan került átadásra vagy nem adtál meg semmit!");
            }

        }

        private void btnExport_Click(object sender, RoutedEventArgs e)
        {
                StreamWriter sw = new StreamWriter("Export.csv", append:true);
                foreach (Diak adat in Frissit)
                {
                    sw.WriteLine($"{adat.OM_Azonosito};{adat.Neve};{adat.Email};{adat.SzuletesiDatum};{adat.ErtesitesiCime};{adat.Matematika};{adat.Magyar}");
                }
                sw.Close();
                this.Close();
        }

        }
    }
