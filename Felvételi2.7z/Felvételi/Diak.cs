﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Felvételi
{
    class Diak:IFelvetelizo
    {

        string omAzonosíto;
        string nev;
        string email;
        DateTime szuletesiDatum;
        string cim;
        int matek, magyar;


        public Diak(string omAzonosíto, string nev, string email, DateTime szuletesiDatum, string cim, int matek, int magyar)
        {
            this.omAzonosíto = omAzonosíto;
            this.nev = nev;
            this.email = email;
            this.szuletesiDatum = szuletesiDatum;
            this.cim = cim;
            this.matek = matek;
            this.magyar = magyar;
            
        }
        public string Email { get => email; set => email = value; }
        public DateTime SzuletesiDatum { get => szuletesiDatum; set => szuletesiDatum = value; }
        public int Magyar { get => magyar; set => magyar = value; }
        public string OM_Azonosito { get => omAzonosíto; set => omAzonosíto = value; }
        public string Neve { get => nev; set => nev = value; }
        public string ErtesitesiCime { get => cim; set => cim = value; }
        public int Matematika { get => matek; set => matek = value; }

        string IFelvetelizo.CSVSortAdVissza()
        {
            throw new NotImplementedException();
        }

        void IFelvetelizo.ModositCSVSorral(string csvString)
        {
            throw new NotImplementedException();
        }
    }
}
