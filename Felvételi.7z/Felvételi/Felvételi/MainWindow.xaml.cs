﻿using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Felvételi
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<adatok> frissit = new ObservableCollection<adatok>();
        public MainWindow()
        {
            InitializeComponent();
        }
        private void btnImport_Click(object sender, RoutedEventArgs e)
        {
           

            
                StreamReader sr = new StreamReader("felveteli.csv");
                while (!sr.EndOfStream)
                {
                    string[] sor = sr.ReadLine().Trim().Split(";");

                    if (sor[5] == "NULL")
                    {
                        sor[5] = "0";
                    }
                    else if (sor[6] == "NULL")
                    {
                        sor[6] = "0";
                    }

                    adatok diak = new adatok(sor[0], sor[1], sor[2], DateTime.Parse(sor[3]), sor[4], int.Parse(sor[5]), int.Parse(sor[6]));
                    frissit.Add(diak);
                }
                sr.Close();
            dgSzoveg.Items.Add(frissit);
        }

        private void btnTorles_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}