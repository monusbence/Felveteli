﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Felvételi
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class userAdd : Window
    {
        public userAdd()
        {
            InitializeComponent();
        }
        private void mentes_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                try
                {
                    // Az adatok összegyűjtése és tárolása
                    string nev = txtNev.Text;
                    string ertesites = txtertesites.Text;
                    string email = txtEmail.Text;
                    string omAzon = txtOmAzon.Text;

                    // Ellenőrzés: legalább a nevet meg kell adni
                    if (string.IsNullOrEmpty(nev))
                    {
                        throw new Exception("Kérlek add meg a nevedet!");
                    }

                    if (string.IsNullOrEmpty(omAzon) || !(omAzon.Length == 11))
                    {
                        throw new Exception("Az OM Azonosítónak 11 karakter hossszúnak kell lennie, ennek megfelelően add meg!");
                    }

                    try
                    {
                        Convert.ToDateTime(txtSzulDatum.Text);
                    }
                    catch (Exception)
                    {
                        throw new Exception("Mikor születtél?");
                    }

                    try
                    {
                        Convert.ToInt16(txtMatekJegy.Text);


                        int matek = Convert.ToInt16(txtMatekJegy.Text);

                        if (matek < 0 || matek > 50)
                        {
                            throw new Exception("Rosszul adtad meg a matek pontszámát!");
                        }
                    }
                    catch (Exception)
                    {
                        throw new Exception("Rosszul adtad meg a matek pontszámát!");
                    }

                    try
                    {
                        int magyar = Convert.ToInt16(txtMagyar.Text);

                        if (magyar < 0 || magyar > 50)
                        {
                            throw new Exception("Rosszul adtad meg a magyar pontszámát!");
                        }
                    }
                    catch (Exception)
                    {
                        throw new Exception("Rosszul adtad meg a magyar pontszámát!");
                    }

                    if (string.IsNullOrEmpty(email) || !email.Contains("@"))
                    {
                        throw new Exception("Kérlek add meg a email címet, szabályos formában!");
                    }


                    if (string.IsNullOrEmpty(ertesites))
                    {
                        throw new Exception("Kérlek add meg a értesítési címet!");
                    }

                    //  a név nem tartalmazhat számokat
                    if (nev.Any(char.IsDigit))
                    {
                        throw new Exception("A név nem tartalmazhat számokat!");
                    }
                    
                        this.Close();
                }

                catch (Exception ex)
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                lblresponse.Content = ex.Message;
            }

        }

        /*private bool IsValidGrade(string jegy)
        {
            if (!double.TryParse(jegy, out double eredmeny))
            {
                // Nem szám
                return false;
            }

            // Az érték 1 és 5 között van
            return eredmeny >= 0 && eredmeny <= 50;
        }*/
    }
}